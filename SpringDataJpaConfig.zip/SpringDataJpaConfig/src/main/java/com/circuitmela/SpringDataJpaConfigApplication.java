package com.circuitmela;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaConfigApplication.class, args);
	}

}
