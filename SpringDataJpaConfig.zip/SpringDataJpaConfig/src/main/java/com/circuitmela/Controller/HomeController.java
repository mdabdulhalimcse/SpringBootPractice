package com.circuitmela.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.circuitmela.model.Programmer;
import com.circuitmela.repository.ProgrammerRepo;

@Controller
public class HomeController {
	
	@Autowired
	private ProgrammerRepo pr;
	
	@GetMapping(value = "/home")
	public String showHome() {
		return "Homepage";
	}

	@PostMapping(value = "/addProgrammer")
	public String showHome(@ModelAttribute Programmer programmer) {
		
		pr.save(programmer);
		return "ProgrammerInfo";
	}
	

}
