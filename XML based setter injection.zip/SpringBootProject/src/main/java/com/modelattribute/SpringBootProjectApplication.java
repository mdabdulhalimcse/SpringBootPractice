package com.modelattribute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ImportResource;

import com.modelattribute.model.Coder;
import com.modelattribute.model.Computer;

@SpringBootApplication
@ImportResource({"classpath:BeanConfig.xml"})
public class SpringBootProjectApplication {

	public static void main(String[] args) {
	ApplicationContext context =	SpringApplication.run(SpringBootProjectApplication.class, args);
		
		
		
		Coder c1 = (Coder)context.getBean("coder1");
		System.out.println(c1.getName());
		System.out.println(c1.getLanguage());
		System.out.println(c1.getComputer().getBrand());
		
		Computer com =(Computer)context.getBean("computer1");
		System.out.println(com.getBrand());
	}

}
