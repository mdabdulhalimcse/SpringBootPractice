package com.circuitmela.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MainController {
	
	@RequestMapping("/home")
	public String HomePage(){
		return "HomePage";
	}
	
//	@RequestMapping("/addProgrammer")
//	public String addProgrammer(Model model, @RequestParam("pId") int i,@RequestParam("pName") String n,@RequestParam String pLang) {
//		model.addAttribute("pId", i);
//		model.addAttribute("pName", n);
//		model.addAttribute("pLang", pLang);
//		
//		return "ProgrammerInfo";
//	}
	
	@RequestMapping("/addProgrammer")
	public ModelAndView addProgrammer( @RequestParam("pId") int i,@RequestParam("pName") String n,@RequestParam String pLang) {
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ProgrammerInfo");
		mv.addObject("pId", i);
		mv.addObject("pName", n);
		mv.addObject("pLang",pLang);
		mv.addObject("data", "Programmer info is given below:");
		
		return mv;
	}

}
