package com.circuitmela.Controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.circuitmela.model.Programmer;



@Controller
public class MainController {
	
	@GetMapping(value = "/allProgrammer")
	public String showAllProgrammerInfo(Model m) {
		
		java.util.List<Programmer> p = new ArrayList<Programmer>();
		p.add(new Programmer(101,"Abdul Halim","Java"));
		p.add(new Programmer(102,"HS Shanto","JavaScript"));
		p.add(new Programmer(103,"Sonali","Cooking"));
		
		m.addAttribute("programmers", p);
		return "AllProgrammer";
	}

}
