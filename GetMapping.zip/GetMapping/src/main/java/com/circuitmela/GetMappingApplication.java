package com.circuitmela;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetMappingApplication.class, args);
	}

}
