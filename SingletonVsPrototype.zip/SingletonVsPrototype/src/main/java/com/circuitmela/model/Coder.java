package com.circuitmela.model;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component
@Scope(value = "prototype")
public class Coder {
	
	public String name;
	
	@Autowired
	Dog dog;

	public Coder() {
		System.out.println("Coder object is created");
	}
	
	public void petInfo() {
		dog.info();
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("Coder object is destroy");
	}
	
	

}
