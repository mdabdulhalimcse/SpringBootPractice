package com.circuitmela.model;

import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

@Component
public class Dog {
	
	public Dog() {
		System.out.println("Dog object is created");
	}
	
	public void info() {
		System.out.println("This is a German Sheperd Dog");
	}
	
	@PreDestroy
	public void showDestroy() {
		System.out.println("Dog object is destroy");
	}

}
