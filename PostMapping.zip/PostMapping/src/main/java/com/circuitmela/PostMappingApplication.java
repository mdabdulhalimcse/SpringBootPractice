package com.circuitmela;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostMappingApplication.class, args);
	}

}
