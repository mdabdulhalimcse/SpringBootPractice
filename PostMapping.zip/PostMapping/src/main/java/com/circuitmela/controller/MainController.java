package com.circuitmela.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.circuitmela.model.Programmer;

@Controller
public class MainController {
	
	@GetMapping("/home")
	public String showHome() {
		return "HomePage";
	}
	
	//	@PostMapping("/addProgrammer")
	@RequestMapping(value="/addProgrammer", method =RequestMethod.POST)
	public String showProgrammerInfo(Model model,@ModelAttribute Programmer programmer) {
		
		return "ProgrammerInfoShow";
	}

}
