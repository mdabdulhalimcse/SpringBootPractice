package com.circuitmela.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.circuitmela.model.Programmer;

@Controller
@ControllerAdvice
public class MainController {
	
	@ModelAttribute
	public void showMsgAllPage(Model model) {
		model.addAttribute("message", "Welcome to Spring boot tutorials ");
	}
	
	@RequestMapping("/home")
	public String showProgrammerInfo() {
		
		return "ProgrammerInfo";
	}
	
	@RequestMapping("/addProgrammer")
	public String showProgrammerInfo(@ModelAttribute Programmer programmer,Model model) {
		model.addAttribute("msg", "Programmer info is here:");
		return "ProgrammerInfoShow";
	}

}
