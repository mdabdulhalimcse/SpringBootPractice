package com.circuitmela.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.circuitmela.model.Coder;
import com.circuitmela.model.Computer;

@Configuration
public class BeanConfig {
	
	@Bean
	public Coder coder1(@Qualifier("computer1") Computer computer) {
		Coder c1 = new Coder(1408,"AbduL Halim","JAVA",computer);
		
		return c1;
	}
	
	@Bean
	public Computer computer1() {
		Computer com1 =new Computer("Intel");
		
		
		return com1;
	}
	
//	@Bean
//	public Coder coder2(@Qualifier("computer2") Computer computer) {
//		Coder c1 = new Coder(1408,"HS Shanto","JAVA & PHP",computer);
//		
//		return c1;
//	}
//	
//	@Bean
//	public Computer computer2() {
//		Computer com1 =new Computer("Intel & AMD");
//		
//		
//		return com1;
//	}
	
	
	@Bean
	public Coder coder2(@Qualifier("computer2") Computer computer) {
		Coder c1 = new Coder();
		c1.setId(1408);
		c1.setName("HS SHanto");
		c1.setLanguage("JAVA & PHP");
		c1.setComputer(computer);
		
		return c1;
	}
	
	@Bean
	public Computer computer2() {
		Computer com1 =new Computer();
		com1.setBrand("Intel & AMD");
		
		
		return com1;
	}
}
