package com.circuitmela.model;

import javax.annotation.PreDestroy;

public class Computer {
	private String brand;

	public Computer() {
		super();
		System.out.println("No arg Constructor in Computer class");
	}

	public Computer(String brand) {
		super();
		this.brand = brand;
		System.out.println("All arg Constructor in Computer class");
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	@PreDestroy
	public void showDestroy() {
		System.out.println("Computer object destroy!");
	}

}
