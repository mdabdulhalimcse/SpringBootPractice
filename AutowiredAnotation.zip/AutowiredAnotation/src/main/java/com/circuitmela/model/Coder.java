package com.circuitmela.model;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Coder {
	
	@Autowired
	Dog dog;

	public Coder() {
		System.out.println("Coder object is created");
	}
	
	public void petInfo() {
		dog.info();
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("Coder object destroyed");
	}
	
	

}
