package com.circuitmela;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.circuitmela.model.Coder;

@SpringBootApplication
public class AutowiredAnotationApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(AutowiredAnotationApplication.class, args);
		
		Coder c1 = context.getBean(Coder.class);
		c1.petInfo();
	}

}
