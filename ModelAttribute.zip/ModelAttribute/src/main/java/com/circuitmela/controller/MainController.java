package com.circuitmela.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.circuitmela.model.Programmer;

@Controller
public class MainController {

	@RequestMapping("/home")
	public String homePage() {
		return "HomePage";
	}

//	@RequestMapping("/addProgrammer")
//	public String addProgrammer(@ModelAttribute Programmer programmer ) {
//		
//		return "ProgrammerInfo";
//	}

	@RequestMapping("/addProgrammer")
	public ModelAndView addProgrammerInfo(@ModelAttribute("p") Programmer programmer) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ProgrammerInfo");

		return mv;
	}

}
